-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : yin_demo
-- 
-- Part : #1
-- Date : 2016-12-28 10:40:01
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `yin_users`
-- -----------------------------
DROP TABLE IF EXISTS `yin_users`;
CREATE TABLE `yin_users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `add_time` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `yin_users`
-- -----------------------------
INSERT INTO `yin_users` VALUES ('7', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1482743536', 'none');
INSERT INTO `yin_users` VALUES ('8', 'admin3', '21232f297a57a5a743894a0e4a801fc3', '1482743770', 'none');
INSERT INTO `yin_users` VALUES ('6', 'aaaaa', '594f803b380a41396ed63dca39503542', '1482736276', 'del');
INSERT INTO `yin_users` VALUES ('9', 'admin4', '21232f297a57a5a743894a0e4a801fc3', '1482744299', 'none');

-- -----------------------------
-- Table structure for `yin_users_information`
-- -----------------------------
DROP TABLE IF EXISTS `yin_users_information`;
CREATE TABLE `yin_users_information` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `users_id` int(255) NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `sex` varchar(20) COLLATE utf8_bin NOT NULL,
  `age` varchar(3) COLLATE utf8_bin NOT NULL,
  `birthday` date NOT NULL,
  `add_time` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `yin_users_information`
-- -----------------------------
INSERT INTO `yin_users_information` VALUES ('8', '7', '尹新�\�', 'boy', '26', '1991-02-11', '1482748240');
INSERT INTO `yin_users_information` VALUES ('7', '8', 'asd', 'girl', '27', '1989-12-03', '1482806092');
