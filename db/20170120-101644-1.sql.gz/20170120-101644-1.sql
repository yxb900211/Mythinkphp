-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : yin_demo
-- 
-- Part : #1
-- Date : 2017-01-20 10:16:44
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `yin_users`
-- -----------------------------
DROP TABLE IF EXISTS `yin_users`;
CREATE TABLE `yin_users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `add_time` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `yin_users`
-- -----------------------------
INSERT INTO `yin_users` VALUES ('6', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('5', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('4', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('7', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('8', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('9', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('10', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('11', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('12', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('13', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('14', '1111', '', '', '');
INSERT INTO `yin_users` VALUES ('15', '1111', '', '', '');

-- -----------------------------
-- Table structure for `yin_users_information`
-- -----------------------------
DROP TABLE IF EXISTS `yin_users_information`;
CREATE TABLE `yin_users_information` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `users_id` int(255) NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `sex` varchar(20) COLLATE utf8_bin NOT NULL,
  `age` varchar(3) COLLATE utf8_bin NOT NULL,
  `birthday` date NOT NULL,
  `add_time` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `yin_users_information`
-- -----------------------------
INSERT INTO `yin_users_information` VALUES ('8', '7', '尹新�\�', 'boy', '26', '1991-02-11', '1482748240');
INSERT INTO `yin_users_information` VALUES ('7', '8', 'asd', 'girl', '27', '1989-12-03', '1482806092');
